# python-iterators-and-iterables
Demo code for python iterators and iterables
