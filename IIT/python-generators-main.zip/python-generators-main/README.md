# python-generators
Demo code for python generators
